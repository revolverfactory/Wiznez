﻿$(function () {
    var bb = $('#belowBanner');
    bb.prepend('<span><a class="navlink" href="default.asp?pg=pgPlugin&sPluginId=kanbanboard@ergonlabs.com">Kanban</a></span>');
});
